# package
Fungsi ? Menginstall Banyak Paket Termux Sekaligus
# How To Install
```
$pkg install git python -y
$git clone https://github.com/MaulanaRyM/package
$cd package
$python install.py
```
Jika sudah menggunakan tool ini, klean ga perlu lgi install paket² seperti php,wget,dll.<br>
Jadi kelan bisa lgsung mengisntall tool yg ingin klean install tanpa mengetik paket yg di perlukan tool tersebut.<br>
<br>
*Enjoyyy*


